/*===============================================
 *   文件名称：server.c
 *   创 建 者：  易   
 *   创建日期：2023年08月30日
 *   描    述：
 ================================================*/
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <sqlite3.h>
#include <time.h>
#define IP  "0.0.0.0"
#define PORT  6666
#define SIZE 64
typedef struct MSG
{
    int type;
    char name[32];
    char data[75];
}msg_t;
msg_t msg;
pid_t pid;
void handler(int signum);
int do_register(int acceptfd, msg_t msg, sqlite3 *db);
int do_login(int acceptfd, sqlite3 *db);
int do_delete(int acceptfd,msg_t msg, sqlite3 *db);
int do_search(int acceptfd, msg_t msg);
void getdate(char *date);
int do_query(int acceptfd, msg_t msg, sqlite3 *db);
int do_history(int acceptfd, msg_t msg, sqlite3 *db);
int history_callback(void* arg, int f_num, char **f_value, char **f_name);
int main(int argc, char *argv[])
{
    sqlite3 *db = NULL;
    if(sqlite3_open("my.db",&db)!=0)
    {
        fprintf(stderr,"%s",sqlite3_errmsg(db));
        return -1;
    }
    char *errmsg = NULL;

    if(sqlite3_exec(db,"create table user(name char,pwd char);",NULL,NULL,&errmsg)!=0)
    {
        fprintf(stderr,"%s",errmsg);
    }
    if(sqlite3_exec(db,"create table record(name char,word char,date char);",NULL,NULL,&errmsg)!=0)
    {
        fprintf(stderr,"%s",errmsg);
    }
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if( -1 == sockfd )
    {
        perror("socket fail");
        return -1;
    }
    printf("socket ok\n");
    struct sockaddr_in saddr = {
        .sin_family   = AF_INET,
        .sin_port     = htons(PORT),
        .sin_addr.s_addr = inet_addr(IP)   //可以匹配当前主机 任意可用ip  类似 "0"
    };
    struct sockaddr_in caddr = {0};
    socklen_t len =sizeof(caddr);
    // 设置地址重用
    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    //bind
    int ret = bind(sockfd,  (struct sockaddr *)&saddr,  sizeof(saddr));
    if( -1 == ret )
    {
        perror("bind fail");
        return -1;
    }
    printf("bind ok\n");
    //listen
    ret = listen(sockfd, 1024);
    if( -1 == ret )
    {
        perror("listen fail");
        return -1;
    }
    printf("listen %d ok\n", ret);  // 3

    signal(SIGCHLD, handler);
    while(1)
    {
        int acceptfd;
        acceptfd = accept(sockfd,(struct sockaddr *)&caddr, &len);
        if(-1 == acceptfd)
        {
            perror("accept");
            return -1;
        }
        printf("ip:%s, port:%d\n",inet_ntoa(caddr.sin_addr),ntohs(caddr.sin_port));
        pid = fork();
        if(-1 == pid)
        {
            perror("fork");
            return -1;
        }else if(0 == pid)
        {
            close(sockfd);
            while(1){
                int ret = recv(acceptfd, &msg, sizeof(msg), 0);
                if(-1 == ret){
                    perror("recv");
                    return -1;
                }else if(0 == ret){
                    printf("客户端已退出\n");
                    break;
                }else{
                    switch(msg.type)
                    {
                        case 1:
                            printf("%s\n",msg.name);
                            do_register(acceptfd, msg, db);
                            break;
                        case 2:
                            printf("%s\n",msg.name);
                            do_login(acceptfd,  db);
                            break;
                        case 3:
                            do_delete(acceptfd,msg, db);
                            break;
                        case 4:
                            printf("msg.name:%s\n", msg.name);
                            //do_search(acceptfd, msg);
                            do_query(acceptfd, msg, db);
                            break;
                        case 5:
                            do_history(acceptfd, msg, db);
                            break;
                        default:
                            break;
                    }

                }
            }

            exit(0); 
        }else{
            close(acceptfd);
        }


    }
    return 0;
}


//处理僵尸进程
void handler(int signum)
{
    while(waitpid(-1, NULL, WNOHANG) > 0);

}
int callback_count(void* pare, int f_num, char **f_value, char **f_name)
{
    int *num = pare;
    *num = atoi(f_value[0]);
    return 0;
}



int do_register(int acceptfd, msg_t msg, sqlite3 *db)
{
    char *errmsg = NULL;
    char sql[BUFSIZ];
    int num_rows = 0;
    int ret;
    snprintf(sql,sizeof(sql), "insert into user values('%s','%s');", msg.name, msg.data);
    if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, " err: %s\n", errmsg);
        strcpy(msg.data,"已有该用户,请重新注册");
    }else{
        strcpy(msg.data, "注册ok");
    }
    ret = send(acceptfd, &msg, sizeof(msg), 0);
    if(-1 == ret)
    {
        perror("send");
        return -1;
    }
    memset(msg.data, 0, sizeof(msg.data));
    msg.type = 0;
    //memset(&msg.name, 0, sizeof(msg.name));
    return 0;
}   
int do_login(int acceptfd, sqlite3 *db)
{
    char *errmsg = NULL;
    char **result = NULL;
    char sql[BUFSIZ];
    int row=0, column;
    int ret;


    sprintf(sql, "select * from user where name='%s' and pwd='%s';", msg.name, msg.data);
    if(sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK) 
    {
        //printf("%s\n",errmsg);
        return -1;
    }else{
        printf("get_table ok\n");
    }
    if(row == 1){
        strcpy(msg.data, "ok");
        send(acceptfd, &msg, sizeof(msg), 0);
        return 1;
    }
    if(row == 0)
    {
        strcpy(msg.data, "fail");
        send(acceptfd, &msg, sizeof(msg), 0);
    }
    printf("%s\n",msg.data);
    memset(msg.data, 0, sizeof(msg.data));
    msg.type = 0;
    return 0;
}
int do_delete(int acceptfd,msg_t msg, sqlite3 *db)
{
    char *errmsg = NULL;
    char sql[BUFSIZ];
    int num_rows = 0;
    int ret;
    snprintf(sql,sizeof(sql), "delete from user where name = '%s';", msg.name);
    if(sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, " err: %s\n", errmsg);
    }else{
        strcpy(msg.data, "注销ok");
    }
    ret = send(acceptfd, &msg, sizeof(msg), 0);
    if(-1 == ret)
    {
        perror("send");
        return -1;
    }
    memset(&msg, 0, sizeof(msg));

    return 0;
}
int do_search(int acceptfd,msg_t msg)
{
    FILE *fd;
    char temp[300] = {0};
    char *p;
    int len = 0, ret = 0;

    len = strlen(msg.data);
    if(NULL == (fd = fopen("dict.txt", "r")))
    {
        strcpy(msg.data, "open error");
        send(acceptfd, &msg, sizeof(msg), 0);
        return -1;
    }
    printf("%s\n", msg.data);

    while(fgets(temp, 300, fd) != NULL)
    {
        ret = strncmp(msg.data, temp, len);

        if(ret == 0 && temp[len] == ' ')
        {
            p = temp + len;
            while(*p == ' ')
            {
                p++;
            }
            //memset(msg.data, 0, sizeof(msg));
            strcpy(msg.data, p);
            printf("%s\n", msg.data);
            send(acceptfd, &msg, sizeof(msg), 0);
            return 1;
        }
    }
    return 0;
}
//查询的日期
void getdate(char *date)
{
    time_t t;
    struct tm *tp;
    time(&t);
    tp = localtime(&t);
    sprintf(date, " %d-%02d-%02d %02d:%02d:%02d\n",tp->tm_year+1900, tp->tm_mon+1, tp->tm_mday, tp->tm_hour,tp->tm_min, tp->tm_sec);
}
int do_query(int acceptfd, msg_t msg, sqlite3 *db)
{

    char *errmsg = NULL;
    char sql[BUFSIZ] = {0};
    char date[300] = {0};
    char word[300] = {0};
    time_t t;
    struct tm *tp;

    int found = 0;
    found = do_search(acceptfd, msg);
    strcpy(word, msg.data);
    if(1 == found){
        getdate(date);
        printf("%s\n",msg.name);

        snprintf(sql, sizeof(sql),"insert into record values('%s','%s','%s');",msg.name, word, date);

        if (sqlite3_exec(db, sql, NULL, NULL, &errmsg) != SQLITE_OK) 
        {
            fprintf(stderr, "insert err: %s\n", errmsg);
            return -1;
        }
    }else if(0 == found){
        strcpy(msg.data, "not found");
    }
    send(acceptfd, &msg, sizeof(msg), 0);
    return 0;
}
int history_callback(void *arg, int f_num, char **f_value,char **f_name)
{
    int acceptfd;
    int ret;
    acceptfd = *((int *)arg);
    sprintf(msg.data, "%s %s : %s", f_value[0], f_value[1], f_value[2]);
    ret = send(acceptfd, &msg, sizeof(msg), 0);
    if(-1 == ret)
    {
        perror("send");
        return -1;
    }
    return 0;
}
int do_history(int acceptfd, msg_t msg, sqlite3 *db)
{
    char *errmsg;
    char sql[125];
    puts(msg.name);
    snprintf(sql,sizeof(sql),"select *from record where name ='%s';", msg.name);
    printf("sql:%s\n",sql);
    if(sqlite3_exec(db, sql, history_callback, (void*)&acceptfd, &errmsg) != 0)
    {
        //fprintf(stderr, "sqliste3_open err:2222%s\n", errmsg);
    }
    if(send(acceptfd, &msg, sizeof(msg), 0) < 0)
    {
        perror("send error");
        return -1;
    }

    strcpy(msg.data,"over");
    if(send(acceptfd, &msg, sizeof(msg), 0) < 0)
    {
        perror("send error");
        return -1;
    }
    return 0;
}
