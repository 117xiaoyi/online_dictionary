/*===============================================
 *   文件名称：client.c
 *   创 建 者：  易   
 *   创建日期：2023年08月30日
 *   描    述：
 ================================================*/
#include <strings.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> 
#include <unistd.h>
#include <stdlib.h>
#include <arpa/inet.h>  
#include <ctype.h>     
#include <signal.h>    
#include <sys/types.h> 
#include <sys/wait.h>
#include <errno.h>    
#include <sqlite3.h>
#define IP  "192.168.198.128"
#define PORT  6666
#define SIZE 64

typedef struct MSG
{
    int type;
    char name[32];
    char data[75];
}msg_t;


msg_t msg;

int do_register(int sockfd, msg_t msg);
int do_login(int sockfd,msg_t msg);
int do_query(int sockfd,msg_t msg);
int do_history(int sockfd,msg_t msg);
int do_delete(int sockfd,msg_t msg);

int main(int argc, char *argv[])
{
    msg.type = 0; 
    memset(msg.name, 0, sizeof(msg.name));
    memset(msg.data, 0, sizeof(msg.data));
    int sockfd = socket(AF_INET,SOCK_STREAM,0);
    if(-1 ==sockfd)
    {
        return -1;
    }
    struct sockaddr_in saddr = {0}; 
    saddr.sin_family         = AF_INET;   //IPV4 协议
    saddr.sin_port           = htons(PORT);    // 端口号 1024-49151
    saddr.sin_addr.s_addr    = inet_addr(IP);   //绑定固定ip 

    int connfd = connect(sockfd, (struct sockaddr* )&saddr, sizeof(saddr));
    if( -1 == connfd )
    {
        perror("connect fail");
        return -1;
    }

    int n = 0;
    int count =0;
    while(1){
        printf("****欢迎来到词语宝盒!*********************\n");
        printf(" 1:注册  2:登陆 3:注销用户 6:退出\n");
        printf("******************************************\n");
        printf("请选择:\n");
        scanf("%d",&n);
        getchar();
        printf("你输入的是%d\n",n);
        switch(n)
        {
            case 1:
                do_register(sockfd,msg);
                break;
            case 2:
                 count = do_login(sockfd,msg);
                break;
            case 3:
                do_delete(sockfd,msg);
                break;
            case 6:
                close(sockfd);
                exit(0);
                break;
            default:
                break;
        }
        if(count ==1)
        {
            break;
        }
    }
    while(1)
    {
        printf("****欢迎来到词语宝盒!*********************\n");
        printf(" 4:查询 5.历史记录  6:退出\n");
        printf("******************************************\n");
        printf("请选择:\n");
        scanf("%d", &n);
        getchar();
        printf("你输入的是%d\n",n);
        switch(n){
            case 4:
                puts(msg.name);
                do_query(sockfd,msg);
                break;
            case 5:
                printf("历史记录:\n");
                do_history(sockfd,msg);
                break;
            case 6:
                close(sockfd);
                exit(0);
                break;
            default:
                break;
        } 
    }
    return 0;
}
int do_register(int sockfd,msg_t msg)
{
    msg.type = 1;
    int ret;
    printf("请输入用户名:");
    scanf("%s",msg.name);
    getchar();
    printf("请输入密码:");
    scanf("%s",msg.data);
    getchar();
    ret = send(sockfd,&msg,sizeof(msg),0);
    if(-1 == ret)
    {
        perror("send");
        return -1;
    }
    ret = recv(sockfd,&msg,sizeof(msg),0);
    if(-1 == ret)
    {
        perror("recv");
        return -1;
    }
    printf("register [%s]:%s\n",msg.name, msg.data);
    return 0;
}
int do_login(int sockfd,msg_t msg)
{
    msg.type = 2;
    int ret;
    printf("请输入登陆用户名:");
    scanf("%s",msg.name);
    getchar();
    printf("请输入登陆密码:");
    scanf("%s",msg.data);
    getchar();
    ret = send(sockfd,&msg,sizeof(msg),0);
    if(-1 == ret)
    {
        perror("send");
        return -1;
    }

    ret = recv(sockfd,&msg,sizeof(msg),0);
    if(-1 == ret)
    {
        perror("recv");
        return -1;
    }
    if(strcmp(msg.data,"ok") == 0){
        printf("登陆成功\n");
    printf("%s\n",msg.name);
        return 1;
    }else{
        printf("登陆失败,请重新登陆\n");
    }
    return 0;
}
int do_delete(int sockfd,msg_t msg)
{
    msg.type = 3;
    int ret;
    printf("请输入注销用户名:");
    scanf("%s",msg.name);
    getchar();
    ret = send(sockfd,&msg,sizeof(msg),0);
    if(-1 == ret)
    {
        perror("send");
        return -1;
    }

    ret = recv(sockfd,&msg,sizeof(msg),0);
    if(-1 == ret)
    {
        perror("recv");
        return -1;
    }
    printf("%s\n",msg.data);
    return 0;
}
int do_query(int sockfd,msg_t msg)
{
    msg.type = 4;
    printf("用户:%s\n",msg.name);
    while(1)
    {
        printf("输入要查询的信息(#退出):\n");
        scanf("%s",msg.data);
        getchar();
        printf("你输入的单词为:%s\n",msg.data);
        if(strcmp(msg.data,"#")==0)
        {
            break;
        }
        if(send(sockfd,&msg,sizeof(msg),0)<0)
        {
            perror("send");
            return -1;
        }
        printf("-------------------------------\n");
        if(recv(sockfd,&msg,sizeof(msg),0)<0)
        {
            perror("recv");
            return -1;
        }
        printf("这个单词意思为:%s\n",msg.data);
    }
    return 0;
}
int do_history(int sockfd,msg_t msg)
{
    msg.type = 5;
    if(send(sockfd,&msg,sizeof(msg),0)<0)
    {
        perror("send");
        return -1;
    }
    while(1){
        if(recv(sockfd,&msg,sizeof(msg),0)<0)
        {
            perror("recv");
            return -1;
        }
        if(0 == strcmp(msg.data,"over"))
        {
            break;
        }
        printf("%s\n",msg.data);
    }
    return 0;
}
